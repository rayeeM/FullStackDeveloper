declare module 'history' {
  declare module.exports: any;
}

declare module 'react-icons/fa' {
  declare module.exports: any;
}
